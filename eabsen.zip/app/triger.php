<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class triger extends Model
{
    //
    protected $table="trigers";
}

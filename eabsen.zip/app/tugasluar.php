<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tugasluar extends Model
{
    //

}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        $bulan=date("m");
        $tahun=date("Y");
        if (isset($request->search)
        {
              $pegawai=pegawai::>join('jadwalkerjas','rulejadwalpegawais.jadwalkerja_id','=','jadwalkerjas.id')
                ->where('pegawais.status_aktif','=','1')
                ->where('pegawais.nip','=',$request->search)
                ->count();
              if ($pegawai>0){

                $pegawai=pegawai::>join('jadwalkerjas','rulejadwalpegawais.jadwalkerja_id','=','jadwalkerjas.id')
                  ->where('pegawais.status_aktif','=','1')
                  ->where('pegawais.nip','=',$request->search)
                  ->first();

              $harikerja = att::
                  // ->whereMonth('atts.tanggal_att', '=', $bulan)re
                  // ->whereYear('atts.tanggal_att', '=', $tahun)
                  ->whereMonth('tanggal_att','=',$bulan)
                  ->whereYear('tanggal_att','=',$tahun)
                  ->where('jenisabsen_id','!=','9')
                  ->where('pegawai_id','=',$pegawai->id)
                  ->count();

                //9 itu libur nasional atau cuti
              $hadir = att::
                  ->whereMonth('tanggal_att','=',$bulan)
                  ->whereYear('tanggal_att','=',$tahun)
                  ->where('jenisabsen_id', '=', '1')
                  ->where('pegawai_id','=',$pegawai->id)
                  ->count();


                  $tidakterlambat = att::join('pegawais', 'atts.pegawai_id', '=', 'pegawais.id')
                      ->join('jadwalkerjas', 'rulejadwalpegawais.jadwalkerja_id', '=', 'jadwalkerjas.id')
                      ->where('atts.jam_masuk', '<', $pegawai->jam_masukjadwal)
                      // ->whereMonth('atts.tanggal_att', '=', $bulan)
                      // ->whereYear('atts.tanggal_att', '=', $tahun)
                      ->whereMonth('atts.tanggal_att','=',$bulan)
                      ->whereYear('atts.tanggal_att','=',$tahun)
                      ->whereNotNull('atts.jam_masuk')
                      ->where('atts.pegawai_id','=',$pegawai->id)
                      ->count();

              $presentaseapel=$tidakterlambat/$harikerja*100;

              $presentasetidakhadir=$hadir/$harikerja*100;


                  $totalakumulasi = att::
                  ->whereMonth('tanggal_att','=',$bulan)
                  ->whereYear('tanggal_att','=',$tahun)
                  ->where('pegawai_id','=',$pegawai->id)
                  ->select(DB::raw('SEC_TO_TIME( SUM(time_to_sec(atts.akumulasi_sehari))) as total'))
                  ->get();
              }
        }
        else
        {


          return view('dashboard.dashboard');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

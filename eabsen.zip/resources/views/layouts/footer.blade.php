<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2017 <a href="diskominfo.kalselprov.go.id">Diskominfo Prov. Kalsel</a>.</strong> All rights
    reserved.
</footer>

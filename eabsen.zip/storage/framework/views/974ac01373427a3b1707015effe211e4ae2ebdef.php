

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('dist/css/skins/_all-skins.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
    <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

      <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">

          <!-- Main content -->
          <section class="content">
            <?php echo $__env->make('layouts.inforekap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Main content -->
            <section class="content">

                <div class="row">
                    <div class="col-md-12" id="app">
                        <!-- The time line -->
                            <!-- timeline time label -->
                            <!-- /.timeline-label -->
                            <!-- timeline item -->
                        <ul class="timeline">
                            <!-- timeline item -->
                            <li v-for="att in atts">
                                <i class="fa fa-map-marker bg-blue"></i>
                                <div class="timeline-item">
                                    <span class="time"><i class="fa fa-clock-o"></i> {{ att.tanggal }}</span>

                                    <h3 class="timeline-header">{{ att.namaPegawai }} <small>dari {{ att.instansiPegawai }}</small></h3>

                                    <div class="timeline-body">
                                        Telah {{ att.statusmasuk }} di <strong>{{ att.namaInstansi }}</strong> pada jam {{ att.jam }}
                                    </div>

                                </div>
                            </li>
                            <?php echo $__env->make('timeline.datatimeline', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </ul>
                        <div class="ajax-load text-center" id="ajax-load" style="display:none">

                            <p><img src="http://demo.itsolutionstuff.com/plugin/loader.gif">Loading More post</p>

                        </div>
                    </div>
                    <!-- /.col -->
                </div>

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <footer class="main-footer">
            <div class="pull-right hidden-xs">
                <b>Version</b> 2.4.0
            </div>
            <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
            reserved.
        </footer>

    </div>
    <!-- ./wrapper -->

    <!-- jQuery 3 -->
    <script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- SlimScroll -->

    <!-- FastClick -->
    <script src="<?php echo e(asset('bower_components/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.4.2/vue.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.3/socket.io.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>

    <script type="text/javascript">
        var socket = io('http://eabsen.dev:3000');
        new Vue({
            el: '#app',
            data: {
                atts: [],
            },
            mounted: function() {
                // 'test-channel:UserSignedUp'

                socket.on('test-channel.<?php echo e(Auth::user()->instansi_id); ?>:App\\Events\\Timeline', function(data) {
                    this.atts.unshift({class:data.class,statusmasuk:data.statusmasuk,namaPegawai:data.namaPegawai,namaInstansi:data.namaInstansi,tanggal:data.tanggal,jam:data.jam,instansiPegawai:data.instansiPegawai})
                     console.log(data)

                }.bind(this))
            }
        })
    </script>

    <script type="text/javascript">
        var page = 1;
        $(window).scroll(function() {
            if($(window).scrollTop() + $(window).height() >= $(document).height()) {
                page++;
                loadMoreData(page);
            }
        });

        function loadMoreData(page){
            $.ajax(
                    {
                        url: '?page=' + page,
                        type: "get",
                        beforeSend: function()
                        {
                            $('#ajax-load').show();
                        }
                    })
                    .done(function(data)
                    {
                        if(data.html == " "){
//                            $('#ajax-load').html("No more records found");
                            return;
                        }
                        $('#ajax-load').hide();
                        $(".timeline").append(data.html);
                    })
                    .fail(function(jqXHR, ajaxOptions, thrownError)
                    {
                        alert('server not responding...');
                    });
        }
    </script>

    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
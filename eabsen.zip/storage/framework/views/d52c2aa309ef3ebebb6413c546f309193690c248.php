

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.css')); ?>">
<!-- bootstrap datepicker -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<!-- iCheck for checkboxes and radio inputs -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/iCheck/all.css')); ?>">
<!-- Bootstrap Color Picker -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css')); ?>">
<!-- Bootstrap time Picker -->
<link rel="stylesheet" href="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/skins/_all-skins.min.css')); ?>">

<script type="text/javascript" src="//cdn.jsdelivr.net/jquery/1/jquery.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap/3/css/bootstrap.css" />

<!-- Include Date Range Picker -->
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
    <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

      <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">

          <!-- Main content -->
          <section class="content">
            <?php echo $__env->make('layouts.inforekap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php if(!empty(session('err'))): ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                    <?php echo e(session('err')); ?>

                </div>
                <?php endif; ?>
                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Atur Jadwal Kerja Pegawai</h3>

                        <div class="box-tools">
                            <form action="/jadwalkerjapegawai" method="post">
                            <div class="input-group input-group-sm" style="width: 150px;">

                                <input type="text" name="table_search" class="form-control pull-right" placeholder="Search" value="<?php echo e($cari); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="input-group-btn">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                            </form>
                        </div>

                    </div>
                    <!-- /.box-header -->
                        <div class="box-body table-responsive no-padding">
                        <form action="/jadwalkerjapegawaiedit" method="post">
                            <div class="row">
                                <div class="col-md-12">

                                    <div class="form-group">
                                        <div class="col-md-4">
                                            <label>Jenis Jadwal Kerja</label>
                                            <select class="form-control" name="jadwalkerjamasuk" data-placeholder="Jenis Jadwal Kerja">
                                                <?php $__currentLoopData = $jadwalkerjas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwalkerja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($jadwalkerja->id); ?>"><?php echo e($jadwalkerja->jenis_jadwal); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-md-3">
                                            <label>Tanggal berlaku</label>
                                            <input type="text" class="form-control" id="daterange" name="daterange"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-md-6">
                                            <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <table class="table table-hover">
                                <tr>
                                    <th>#</th>
                                    <th>NIP</th>
                                    <th>Nama</th>
                                    <th>Jabatan</th>
                                </tr>

                                <?php $__currentLoopData = $rulejadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rulejadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="checkbox[]" value="<?php echo e($rulejadwal->id); ?>" class="flat-red">
                                    </td>
                                    <td><?php echo e($rulejadwal->nip); ?></td>
                                    <td><?php echo e($rulejadwal->nama); ?></td>
                                    <td><?php echo e($rulejadwal->jabatan); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </form>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer clearfix">
                            <ul class="pagination pagination-sm no-margin pull-right">
                                <?php echo e($rulejadwals->links()); ?>

                            </ul>
                        </div>
                </div>

                <div class="box">
                    <div class="box-header">
                        <h3 class="box-title">Manajemen Jadwal Kerja Pegawai</h3>

                        <div class="box-tools">
                            <form action="/jadwalkerjapegawai" method="post">
                                <div class="input-group input-group-sm" style="width: 150px;">

                                    <input type="text" name="table_search2" class="form-control pull-right" placeholder="Search" value="<?php echo e($cari2); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="input-group-btn">
                                        <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">

                            <table class="table table-hover">
                                <tr>
                                    <th>NIP</th>
                                    <th>Nama</th>
                                    <th>Jabatan</th>
                                    <th>Jenis Jadwal</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Tanggal Akhir</th>
                                    <th>Aksi</th>
                                </tr>

                                <?php $__currentLoopData = $rulejadwals2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rulejadwal2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($rulejadwal2->nip); ?></td>
                                        <td><?php echo e($rulejadwal2->nama); ?></td>
                                        <td><?php echo e($rulejadwal2->jabatan); ?></td>
                                        <td><?php echo e($rulejadwal2->jenis_jadwal); ?></td>
                                        <td><?php echo e($rulejadwal2->tanggal_awalrule); ?></td>
                                        <td><?php echo e($rulejadwal2->tanggal_akhirrule); ?></td>
                                        <td><a class="btn-sm btn-success" href="/jadwalkerjapegawai/<?php echo e($rulejadwal2->id); ?>/edit">Edit</a>
                                            <a class="btn-sm btn-danger" data-method="delete"
                                               data-token="<?php echo e(csrf_token()); ?>" href="/jadwalkerjapegawai/<?php echo e($rulejadwal2->id); ?>/hapus">Hapus</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                    </div>
                    <!-- /.box-body -->

                    <div class="box-footer clearfix">
                        <ul class="pagination pagination-sm no-margin pull-right">
                            <?php echo e($rulejadwals2->links()); ?>

                        </ul>
                    </div>
                </div>
                <!-- /.row -->

            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <footer class="main-footer">
            <div class="pull-right hidden-xs">
                <b>Version</b> 2.4.0
            </div>
            <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
            reserved.
        </footer>
    </div>
    <!-- ./wrapper -->

    <script src="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
    <!-- jQuery 3 -->
    <script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- SlimScroll -->

    <!-- Select2 -->
    <script src="<?php echo e(asset('bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <!-- InputMask -->
    <script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
    <!-- date-range-picker -->
    <script src="<?php echo e(asset('bower_components/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <!-- bootstrap color picker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>"></script>
    <!-- bootstrap time picker -->
    <script src="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
    <!-- SlimScroll -->
    <script src="<?php echo e(asset('bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
    <!-- iCheck 1.0.1 -->
    <script src="<?php echo e(asset('plugins/iCheck/icheck.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('bower_components/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>


        <script type="text/javascript">
            $(function() {
                $('input[name="daterange"]').daterangepicker(
                        {
                            locale: {
                                format: 'YYYY/MM/DD'
                            }
                        }
                );
            });

        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
            checkboxClass: 'icheckbox_minimal-blue',
            radioClass   : 'iradio_minimal-blue'
        })
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass   : 'iradio_minimal-red'
        })
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass   : 'iradio_flat-green'
        })
    </script>

    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
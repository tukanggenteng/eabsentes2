<?php $__currentLoopData = $attstrans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attstran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
    <i class="fa fa-map-marker bg-blue"></i>

    <div class="timeline-item">
        <span class="time"><i class="fa fa-clock-o"></i> <?php echo e($attstran->tanggal); ?></span>

        <h3 class="timeline-header"><?php echo e($attstran->nama); ?> <small>dari <?php echo e($attstran->instansiPegawai); ?></small></h3>

        <div class="timeline-body">
            Telah <?php if( $attstran->status_kedatangan=="0"): ?> hadir <?php else: ?> pulang <?php endif; ?> di <strong><?php echo e($attstran->namaInstansi); ?></strong> pada jam <?php echo e($attstran->jam); ?>

        </div>


        
        
        
        
    </div>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
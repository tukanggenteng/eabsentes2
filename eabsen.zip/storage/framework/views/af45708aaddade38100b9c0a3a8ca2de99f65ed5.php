<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>">
<!-- Ionicons -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>">
<!-- daterange picker -->

<link rel="stylesheet" href="<?php echo e(asset('bower_components/loading/loading.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.css')); ?>">
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/select2/dist/css/select2.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('plugins/pace/pace.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">


<?php $__env->stopPush(); ?>

<?php $__env->startSection('body'); ?>
    <body class="hold-transition skin-blue sidebar-mini">

    <div class="wrapper">
        <header class="main-header">
            <!-- Logo -->
            <a href="../../index2.html" class="logo">
                <!-- mini logo for sidebar mini 50x50 pixels -->
                <span class="logo-mini"><b>A</b>LT</span>
                <!-- logo for regular state and mobile devices -->
                <span class="logo-lg"><b>Admin</b>LTE</span>
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top">
                <!-- Sidebar toggle button-->
                <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>

                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <!-- Messages: style can be found in dropdown.less-->
                        <li class="dropdown messages-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-envelope-o"></i>
                                <span class="label label-success">4</span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="header">You have 4 messages</li>
                                <li>
                                    <!-- inner menu: contains the actual data -->
                                    <ul class="menu">
                                        <li><!-- start message -->
                                            <a href="#">
                                                <div class="pull-left">
                                                    <img src="../../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                                                </div>
                                                <h4>
                                                    Support Team
                                                    <small><i class="fa fa-clock-o"></i> 5 mins</small>
                                                </h4>
                                                <p>Why not buy a new awesome theme?</p>
                                            </a>
                                        </li>
                                        <!-- end message -->
                                        <li>
                                            <a href="#">
                                                <div class="pull-left">
                                                    <img src="../../dist/img/user3-128x128.jpg" class="img-circle" alt="User Image">
                                                </div>
                                                <h4>
                                                    AdminLTE Design Team
                                                    <small><i class="fa fa-clock-o"></i> 2 hours</small>
                                                </h4>
                                                <p>Why not buy a new awesome theme?</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div class="pull-left">
                                                    <img src="../../dist/img/user4-128x128.jpg" class="img-circle" alt="User Image">
                                                </div>
                                                <h4>
                                                    Developers
                                                    <small><i class="fa fa-clock-o"></i> Today</small>
                                                </h4>
                                                <p>Why not buy a new awesome theme?</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div class="pull-left">
                                                    <img src="../../dist/img/user3-128x128.jpg" class="img-circle" alt="User Image">
                                                </div>
                                                <h4>
                                                    Sales Department
                                                    <small><i class="fa fa-clock-o"></i> Yesterday</small>
                                                </h4>
                                                <p>Why not buy a new awesome theme?</p>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div class="pull-left">
                                                    <img src="../../dist/img/user4-128x128.jpg" class="img-circle" alt="User Image">
                                                </div>
                                                <h4>
                                                    Reviewers
                                                    <small><i class="fa fa-clock-o"></i> 2 days</small>
                                                </h4>
                                                <p>Why not buy a new awesome theme?</p>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="footer"><a href="#">See All Messages</a></li>
                            </ul>
                        </li>
                        <!-- Notifications: style can be found in dropdown.less -->
                        <li class="dropdown notifications-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-bell-o"></i>
                                <span class="label label-warning">10</span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="header">You have 10 notifications</li>
                                <li>
                                    <!-- inner menu: contains the actual data -->
                                    <ul class="menu">
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-users text-aqua"></i> 5 new members joined today
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-warning text-yellow"></i> Very long description here that may not fit into the
                                                page and may cause design problems
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-users text-red"></i> 5 new members joined
                                            </a>
                                        </li>

                                        <li>
                                            <a href="#">
                                                <i class="fa fa-shopping-cart text-green"></i> 25 sales made
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa fa-user text-red"></i> You changed your username
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="footer"><a href="#">View all</a></li>
                            </ul>
                        </li>
                        <!-- Tasks: style can be found in dropdown.less -->
                        <li class="dropdown tasks-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-flag-o"></i>
                                <span class="label label-danger">9</span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="header">You have 9 tasks</li>
                                <li>
                                    <!-- inner menu: contains the actual data -->
                                    <ul class="menu">
                                        <li><!-- Task item -->
                                            <a href="#">
                                                <h3>
                                                    Design some buttons
                                                    <small class="pull-right">20%</small>
                                                </h3>
                                                <div class="progress xs">
                                                    <div class="progress-bar progress-bar-aqua" style="width: 20%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                                                        <span class="sr-only">20% Complete</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <!-- end task item -->
                                        <li><!-- Task item -->
                                            <a href="#">
                                                <h3>
                                                    Create a nice theme
                                                    <small class="pull-right">40%</small>
                                                </h3>
                                                <div class="progress xs">
                                                    <div class="progress-bar progress-bar-green" style="width: 40%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                                                        <span class="sr-only">40% Complete</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <!-- end task item -->
                                        <li><!-- Task item -->
                                            <a href="#">
                                                <h3>
                                                    Some task I need to do
                                                    <small class="pull-right">60%</small>
                                                </h3>
                                                <div class="progress xs">
                                                    <div class="progress-bar progress-bar-red" style="width: 60%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                                                        <span class="sr-only">60% Complete</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <!-- end task item -->
                                        <li><!-- Task item -->
                                            <a href="#">
                                                <h3>
                                                    Make beautiful transitions
                                                    <small class="pull-right">80%</small>
                                                </h3>
                                                <div class="progress xs">
                                                    <div class="progress-bar progress-bar-yellow" style="width: 80%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                                                        <span class="sr-only">80% Complete</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </li>
                                        <!-- end task item -->
                                    </ul>
                                </li>
                                <li class="footer">
                                    <a href="#">View all tasks</a>
                                </li>
                            </ul>
                        </li>
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="../../dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
                                <span class="hidden-xs">Alexander Pierce</span>
                            </a>
                            <ul class="dropdown-menu">
                                <!-- User image -->
                                <li class="user-header">
                                    <img src="../../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                                    <p>
                                        Alexander Pierce - Web Developer
                                        <small>Member since Nov. 2012</small>
                                    </p>
                                </li>
                                <!-- Menu Body -->
                                <li class="user-body">
                                    <div class="row">
                                        <div class="col-xs-4 text-center">
                                            <a href="#">Followers</a>
                                        </div>
                                        <div class="col-xs-4 text-center">
                                            <a href="#">Sales</a>
                                        </div>
                                        <div class="col-xs-4 text-center">
                                            <a href="#">Friends</a>
                                        </div>
                                    </div>
                                    <!-- /.row -->
                                </li>
                                <!-- Menu Footer-->
                                <li class="user-footer">
                                    <div class="pull-left">
                                        <a href="#" class="btn btn-default btn-flat">Profile</a>
                                    </div>
                                    <div class="pull-right">
                                        <a href="#" class="btn btn-default btn-flat">Sign out</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- Left side column. contains the logo and sidebar -->
        <aside class="main-sidebar">
            <!-- sidebar: style can be found in sidebar.less -->
            <section class="sidebar">
                <!-- Sidebar user panel -->
                <div class="user-panel">
                    <div class="pull-left image">
                        <img src="../../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                    </div>
                    <div class="pull-left info">
                        <p>Alexander Pierce</p>
                        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
                    </div>
                </div>
                <!-- search form -->
                <form action="#" method="get" class="sidebar-form">
                    <div class="input-group">
                        <input type="text" name="q" class="form-control" placeholder="Search...">
                        <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
                    </div>
                </form>
                <!-- /.search form -->
                <!-- sidebar menu: : style can be found in sidebar.less -->
                <ul class="sidebar-menu" data-widget="tree">
                    <li class="header">MAIN NAVIGATION</li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="../../index.html"><i class="fa fa-circle-o"></i> Dashboard v1</a></li>
                            <li><a href="../../index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-files-o"></i>
                            <span>Layout Options</span>
                            <span class="pull-right-container">
              <span class="label label-primary pull-right">4</span>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="../layout/top-nav.html"><i class="fa fa-circle-o"></i> Top Navigation</a></li>
                            <li><a href="../layout/boxed.html"><i class="fa fa-circle-o"></i> Boxed</a></li>
                            <li><a href="../layout/fixed.html"><i class="fa fa-circle-o"></i> Fixed</a></li>
                            <li><a href="../layout/collapsed-sidebar.html"><i class="fa fa-circle-o"></i> Collapsed Sidebar</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="../widgets.html">
                            <i class="fa fa-th"></i> <span>Widgets</span>
                            <span class="pull-right-container">
              <small class="label pull-right bg-green">new</small>
            </span>
                        </a>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-pie-chart"></i>
                            <span>Charts</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="../charts/chartjs.html"><i class="fa fa-circle-o"></i> ChartJS</a></li>
                            <li><a href="../charts/morris.html"><i class="fa fa-circle-o"></i> Morris</a></li>
                            <li><a href="../charts/flot.html"><i class="fa fa-circle-o"></i> Flot</a></li>
                            <li><a href="../charts/inline.html"><i class="fa fa-circle-o"></i> Inline charts</a></li>
                        </ul>
                    </li>
                    <li class="treeview active">
                        <a href="#">
                            <i class="fa fa-laptop"></i>
                            <span>UI Elements</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="general.html"><i class="fa fa-circle-o"></i> General</a></li>
                            <li><a href="icons.html"><i class="fa fa-circle-o"></i> Icons</a></li>
                            <li><a href="buttons.html"><i class="fa fa-circle-o"></i> Buttons</a></li>
                            <li><a href="sliders.html"><i class="fa fa-circle-o"></i> Sliders</a></li>
                            <li><a href="timeline.html"><i class="fa fa-circle-o"></i> Timeline</a></li>
                            <li class="active"><a href="modals.html"><i class="fa fa-circle-o"></i> Modals</a></li>
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-edit"></i> <span>Forms</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="../forms/general.html"><i class="fa fa-circle-o"></i> General Elements</a></li>
                            <li><a href="../forms/advanced.html"><i class="fa fa-circle-o"></i> Advanced Elements</a></li>
                            <li><a href="../forms/editors.html"><i class="fa fa-circle-o"></i> Editors</a></li>
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-table"></i> <span>Tables</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="../tables/simple.html"><i class="fa fa-circle-o"></i> Simple tables</a></li>
                            <li><a href="../tables/data.html"><i class="fa fa-circle-o"></i> Data tables</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="../calendar.html">
                            <i class="fa fa-calendar"></i> <span>Calendar</span>
                            <span class="pull-right-container">
              <small class="label pull-right bg-red">3</small>
              <small class="label pull-right bg-blue">17</small>
            </span>
                        </a>
                    </li>
                    <li>
                        <a href="../mailbox/mailbox.html">
                            <i class="fa fa-envelope"></i> <span>Mailbox</span>
                            <span class="pull-right-container">
              <small class="label pull-right bg-yellow">12</small>
              <small class="label pull-right bg-green">16</small>
              <small class="label pull-right bg-red">5</small>
            </span>
                        </a>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-folder"></i> <span>Examples</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="../examples/invoice.html"><i class="fa fa-circle-o"></i> Invoice</a></li>
                            <li><a href="../examples/profile.html"><i class="fa fa-circle-o"></i> Profile</a></li>
                            <li><a href="../examples/login.html"><i class="fa fa-circle-o"></i> Login</a></li>
                            <li><a href="../examples/register.html"><i class="fa fa-circle-o"></i> Register</a></li>
                            <li><a href="../examples/lockscreen.html"><i class="fa fa-circle-o"></i> Lockscreen</a></li>
                            <li><a href="../examples/404.html"><i class="fa fa-circle-o"></i> 404 Error</a></li>
                            <li><a href="../examples/500.html"><i class="fa fa-circle-o"></i> 500 Error</a></li>
                            <li><a href="../examples/blank.html"><i class="fa fa-circle-o"></i> Blank Page</a></li>
                            <li><a href="../examples/pace.html"><i class="fa fa-circle-o"></i> Pace Page</a></li>
                        </ul>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-share"></i> <span>Multilevel</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li><a href="#"><i class="fa fa-circle-o"></i> Level One</a></li>
                            <li class="treeview">
                                <a href="#"><i class="fa fa-circle-o"></i> Level One
                                    <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
                                </a>
                                <ul class="treeview-menu">
                                    <li><a href="#"><i class="fa fa-circle-o"></i> Level Two</a></li>
                                    <li class="treeview">
                                        <a href="#"><i class="fa fa-circle-o"></i> Level Two
                                            <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                                        </a>
                                        <ul class="treeview-menu">
                                            <li><a href="#"><i class="fa fa-circle-o"></i> Level Three</a></li>
                                            <li><a href="#"><i class="fa fa-circle-o"></i> Level Three</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="#"><i class="fa fa-circle-o"></i> Level One</a></li>
                        </ul>
                    </li>
                    <li><a href="https://adminlte.io/docs"><i class="fa fa-book"></i> <span>Documentation</span></a></li>
                    <li class="header">LABELS</li>
                    <li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>Important</span></a></li>
                    <li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>Warning</span></a></li>
                    <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>Information</span></a></li>
                </ul>
            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>
                    Modals
                    <small>new</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li><a href="#">UI</a></li>
                    <li class="active">Modals</li>
                </ol>
            </section>

            <!-- Main content -->
            <section class="content">

                
                    
                        
                        
                        
                    
                
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box box-default">
                            <div class="box-header with-border">
                                <h3 class="box-title">Manajemen User</h3>
                            </div>
                            <div class="box-body">
                                <hr>
                                <div class="table-responsive">
                                    <table id="tableaja" class="table">
                                        <thead>
                                        <tr>
                                            <th>NIP</th>
                                            <th>Nama</th>
                                            <th>Periode</th>
                                            <th>Ijin</th>
                                            <th>Cuti</th>
                                            <th>Sakit</th>
                                            <th>Tugas Luar</th>
                                            <th>Tugas Belajar</th>
                                            <th>Rapat/ Undangan</th>
                                            <th>Ijin Terlambat</th>
                                        </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                
                <div class="modal fade" id="modal_ijin">
                        <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Upload Surat Ijin</h4>
                            </div>
                            <div class="modal-body">

                                <div class="error alert-danger alert-dismissible">
                                </div>
                                <form id="formijin" method="post" role="form" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>NIP</label>
                                                <input id="nipijin" name="nipijin" readonly class="form-control pull-right" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama</label>
                                                <input id="namaijin" name="namaijin" readonly class="form-control pull-right" type="text">
                                                <?php echo e(csrf_field()); ?>

                                            </div>
                                            <div class="form-group">
                                                <label>Lama Hari</label>
                                                <select class="form-control select2" id="lamaijin" name="lamaijin" style="width: 100%;">
                                                </select>
                                            </div>
                                            <div class="form-group" >
                                                <label>Sejak Tanggal</label>
                                                <input id="tanggalijin" readonly name="tanggalijin" class="form-control datepicker pull-right" type="text">
                                                <input id="idijin" readonly hidden name="idijin" type="text">
                                                <input id="sisalamaijin" readonly hidden name="sisalamaijin" type="text">
                                            </div>
                                            <div class="form-group" >
                                                <label>Upload File</label>
                                                <input id="fileijin" name="fileijin" class="filestyle" data-btnClass="btn-primary" type="file">
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="button" id="simpanijin" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
        
            
            
            
            
        
                <!-- /.modal -->
                
                <div class="modal fade" id="modal_sakit">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Upload Surat Sakit</h4>
                            </div>
                            <div class="modal-body">
                                <div class="error alert-danger alert-dismissible">
                                </div>
                                <form id="formsakit" method="post" role="form" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>NIP</label>
                                                <input id="nipsakit" name="nipsakit" readonly class="form-control pull-right" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama</label>
                                                <input id="namasakit" name="namasakit" readonly class="form-control pull-right" type="text">
                                                <?php echo e(csrf_field()); ?>

                                            </div>
                                            <div class="form-group">
                                                <label>Lama Hari</label>
                                                <select class="form-control select2" id="lamasakit" name="lamasakit" style="width: 100%;">
                                                </select>
                                            </div>
                                            <div class="form-group" >
                                                <label>Sejak Tanggal</label>
                                                <input id="tanggalsakit" readonly name="tanggalsakit" class="form-control datepicker pull-right" type="text">
                                                <input id="idsakit" readonly hidden name="idsakit" type="text">
                                                <input id="sisalamasakit" readonly hidden name="sisalamasakit" type="text">
                                            </div>
                                            <div class="form-group" >
                                                <label>Upload File</label>
                                                <input id="filesakit" name="filesakit" class="filestyle" data-btnClass="btn-primary" type="file">
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="button" id="simpansakit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->

                
                <div class="modal fade" id="modal_cuti">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Upload Surat Cuti</h4>
                            </div>
                            <div class="modal-body">
                                <div class="error alert-danger alert-dismissible">
                                </div>
                                <form id="formcuti" method="post" role="form" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>NIP</label>
                                                <input id="nipcuti" name="nipcuti" readonly class="form-control pull-right" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama</label>
                                                <input id="namacuti" name="namacuti" readonly class="form-control pull-right" type="text">
                                                <?php echo e(csrf_field()); ?>

                                            </div>
                                            <div class="form-group">
                                                <label>Lama Hari</label>
                                                <select class="form-control select2" id="lamacuti" name="lamacuti" style="width: 100%;">
                                                </select>
                                            </div>
                                            <div class="form-group" >
                                                <label>Sejak Tanggal</label>
                                                <input id="tanggalcuti" readonly name="tanggalcuti" class="form-control datepicker pull-right" type="text">
                                                <input id="idcuti" readonly hidden name="idcuti" type="text">
                                                <input id="sisalamacuti" readonly hidden name="sisalamacuti" type="text">
                                            </div>
                                            <div class="form-group" >
                                                <label>Upload File</label>
                                                <input id="filecuti" name="filecuti" class="filestyle" data-btnClass="btn-primary" type="file">
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="button" id="simpancuti" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->

                
                <div class="modal fade" id="modal_tb">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Upload Surat Tugas Belajar</h4>
                            </div>
                            <div class="modal-body">
                                <div class="error alert-danger alert-dismissible">
                                </div>
                                <form id="formtb" method="post" role="form" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>NIP</label>
                                                <input id="niptb" name="niptb" readonly class="form-control pull-right" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama</label>
                                                <input id="namatb" name="namatb" readonly class="form-control pull-right" type="text">
                                                <?php echo e(csrf_field()); ?>

                                            </div>
                                            <div class="form-group">
                                                <label>Lama Hari</label>
                                                <select class="form-control select2" id="lamatb" name="lamatb" style="width: 100%;">
                                                </select>
                                            </div>
                                            <div class="form-group" >
                                                <label>Sejak Tanggal</label>
                                                <input id="tanggaltb" readonly name="tanggaltb" class="form-control datepicker pull-right" type="text">
                                                <input id="idtb" readonly hidden name="idtb" type="text">
                                                <input id="sisalamatb" readonly hidden name="sisalamatb" type="text">
                                            </div>
                                            <div class="form-group" >
                                                <label>Upload File</label>
                                                <input id="filetb" name="filetb" class="filestyle" data-btnClass="btn-primary" type="file">
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="button" id="simpantb" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->

                
                <div class="modal fade" id="modal_tl">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Upload Surat Tugas Luar</h4>
                            </div>
                            <div class="modal-body">
                                <div class="error alert-danger alert-dismissible">
                                </div>
                                <form id="formtl" method="post" role="form" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>NIP</label>
                                                <input id="niptl" name="niptl" readonly class="form-control pull-right" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama</label>
                                                <input id="namatl" name="namatl" readonly class="form-control pull-right" type="text">
                                                <?php echo e(csrf_field()); ?>

                                            </div>
                                            <div class="form-group">
                                                <label>Lama Hari</label>
                                                <select class="form-control select2" id="lamatl" name="lamatl" style="width: 100%;">
                                                </select>
                                            </div>
                                            <div class="form-group" >
                                                <label>Sejak Tanggal</label>
                                                <input id="tanggaltl" readonly name="tanggaltl" class="form-control datepicker pull-right" type="text">
                                                <input id="idtl" readonly hidden name="idtl" type="text">
                                                <input id="sisalamatl" readonly hidden name="sisalamatl" type="text">
                                            </div>
                                            <div class="form-group" >
                                                <label>Upload File</label>
                                                <input id="filetl" name="filetl" class="filestyle" data-btnClass="btn-primary" type="file">
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="button" id="simpantl" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->

                
                <div class="modal fade" id="modal_rp">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Upload Surat Rapat/ Undangan</h4>
                            </div>
                            <div class="modal-body">
                                <div class="error alert-danger alert-dismissible">
                                </div>
                                <form id="formrp" method="post" role="form" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>NIP</label>
                                                <input id="niprp" name="niprp" readonly class="form-control pull-right" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama</label>
                                                <input id="namarp" name="namarp" readonly class="form-control pull-right" type="text">
                                                <?php echo e(csrf_field()); ?>

                                            </div>
                                            <div class="form-group">
                                                <label>Lama Hari</label>
                                                <select class="form-control select2" id="lamarp" name="lamarp" style="width: 100%;">
                                                </select>
                                            </div>
                                            <div class="form-group" >
                                                <label>Sejak Tanggal</label>
                                                <input id="tanggalrp" readonly name="tanggalrp" class="form-control datepicker pull-right" type="text">
                                                <input id="idrp" readonly hidden name="idrp" type="text">
                                                <input id="sisalamarp" readonly hidden name="sisalamarp" type="text">
                                            </div>
                                            <div class="form-group" >
                                                <label>Upload File</label>
                                                <input id="filerp" name="filerp" class="filestyle" data-btnClass="btn-primary" type="file">
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="button" id="simpanrp" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->

                
                <div class="modal fade" id="modal_it">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Upload Surat Ijin Terlambat</h4>
                            </div>
                            <div class="modal-body">
                                <div class="error alert-danger alert-dismissible">
                                </div>
                                <form id="formit" method="post" role="form" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>NIP</label>
                                                <input id="nipit" name="nipit" readonly class="form-control pull-right" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Nama</label>
                                                <input id="namait" name="namait" readonly class="form-control pull-right" type="text">
                                                <?php echo e(csrf_field()); ?>

                                            </div>
                                            <div class="form-group">
                                                <label>Lama Hari</label>
                                                <select class="form-control select2" id="lamait" name="lamait" style="width: 100%;">
                                                </select>
                                            </div>
                                            <div class="form-group" >
                                                <label>Sejak Tanggal</label>
                                                <input id="tanggalit" readonly name="tanggalit" class="form-control datepicker pull-right" type="text">
                                                <input id="idit" readonly hidden name="idit" type="text">
                                                <input id="sisalamait" readonly hidden name="sisalamait" type="text">
                                            </div>
                                            <div class="form-group" >
                                                <label>Upload File</label>
                                                <input id="fileit" name="fileit" class="filestyle" data-btnClass="btn-primary" type="file">
                                            </div>
                                            <!-- /.form-group -->
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                <button type="button" id="simpanit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->
                <!-- /.modal -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <footer class="main-footer">
            <div class="pull-right hidden-xs">
                <b>Version</b> 2.4.0
            </div>
            <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
            reserved.
        </footer>

        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Create the tabs -->
            <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
                <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>

                <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
            </ul>
            <!-- Tab panes -->
            <div class="tab-content">
                <!-- Home tab content -->
                <div class="tab-pane" id="control-sidebar-home-tab">
                    <h3 class="control-sidebar-heading">Recent Activity</h3>
                    <ul class="control-sidebar-menu">
                        <li>
                            <a href="javascript:void(0)">
                                <i class="menu-icon fa fa-birthday-cake bg-red"></i>

                                <div class="menu-info">
                                    <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                                    <p>Will be 23 on April 24th</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <i class="menu-icon fa fa-user bg-yellow"></i>

                                <div class="menu-info">
                                    <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                                    <p>New phone +1(800)555-1234</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

                                <div class="menu-info">
                                    <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                                    <p>nora@example.com</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <i class="menu-icon fa fa-file-code-o bg-green"></i>

                                <div class="menu-info">
                                    <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                                    <p>Execution time 5 seconds</p>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <!-- /.control-sidebar-menu -->

                    <h3 class="control-sidebar-heading">Tasks Progress</h3>
                    <ul class="control-sidebar-menu">
                        <li>
                            <a href="javascript:void(0)">
                                <h4 class="control-sidebar-subheading">
                                    Custom Template Design
                                    <span class="label label-danger pull-right">70%</span>
                                </h4>

                                <div class="progress progress-xxs">
                                    <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <h4 class="control-sidebar-subheading">
                                    Update Resume
                                    <span class="label label-success pull-right">95%</span>
                                </h4>

                                <div class="progress progress-xxs">
                                    <div class="progress-bar progress-bar-success" style="width: 95%"></div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <h4 class="control-sidebar-subheading">
                                    Laravel Integration
                                    <span class="label label-warning pull-right">50%</span>
                                </h4>

                                <div class="progress progress-xxs">
                                    <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">
                                <h4 class="control-sidebar-subheading">
                                    Back End Framework
                                    <span class="label label-primary pull-right">68%</span>
                                </h4>

                                <div class="progress progress-xxs">
                                    <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <!-- /.control-sidebar-menu -->

                </div>
                <!-- /.tab-pane -->
                <!-- Stats tab content -->
                <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
                <!-- /.tab-pane -->
                <!-- Settings tab content -->
                <div class="tab-pane" id="control-sidebar-settings-tab">
                    <form method="post">
                        <h3 class="control-sidebar-heading">General Settings</h3>

                        <div class="form-group">
                            <label class="control-sidebar-subheading">
                                Report panel usage
                                <input type="checkbox" class="pull-right" checked>
                            </label>

                            <p>
                                Some information about this general settings option
                            </p>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group">
                            <label class="control-sidebar-subheading">
                                Allow mail redirect
                                <input type="checkbox" class="pull-right" checked>
                            </label>

                            <p>
                                Other sets of options are available
                            </p>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group">
                            <label class="control-sidebar-subheading">
                                Expose author name in posts
                                <input type="checkbox" class="pull-right" checked>
                            </label>

                            <p>
                                Allow the user to show his name in blog posts
                            </p>
                        </div>
                        <!-- /.form-group -->

                        <h3 class="control-sidebar-heading">Chat Settings</h3>

                        <div class="form-group">
                            <label class="control-sidebar-subheading">
                                Show me as online
                                <input type="checkbox" class="pull-right" checked>
                            </label>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group">
                            <label class="control-sidebar-subheading">
                                Turn off notifications
                                <input type="checkbox" class="pull-right">
                            </label>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group">
                            <label class="control-sidebar-subheading">
                                Delete chat history
                                <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
                            </label>
                        </div>
                        <!-- /.form-group -->
                    </form>
                </div>
                <!-- /.tab-pane -->
            </div>
        </aside>
        <!-- /.control-sidebar -->
        <!-- Add the sidebar's background. This div must be placed
             immediately after the control sidebar -->
        <div class="control-sidebar-bg"></div>
    </div>
    <!-- ./wrapper -->

    <!-- jQuery 3 -->
    <script src="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- Select2 -->
    
    <!-- DataTables -->
    <script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <!-- FastClick -->


    <script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script src="<?php echo e(asset('bower_components/bootstrap-filestyle/bootstrap-filestyle.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
    <!-- AdminLTE for demo purposes -->
    
    <!-- Page script -->
    
        
            
            

        
    
    <script type="text/javascript">

        $(function() {
            $('input[name="tanggalijin"]').datepicker({
                firstDay: 1,
                format: "yyyy-mm-dd",
                startDate:"-1w",
                endDate:"-1d",
            });
            $('input[name="tanggalsakit"]').datepicker({
                firstDay: 1,
                format: "yyyy-mm-dd",
                startDate:"-1w",
                endDate:"-1d",
            });
            $('input[name="tanggalcuti"]').datepicker({
                firstDay: 1,
                format: "yyyy-mm-dd",
                startDate:"-1w",
                endDate:"-1d",
            });
            $('input[name="tanggaltb"]').datepicker({
                firstDay: 1,
                format: "yyyy-mm-dd",
                startDate:"-1w",
                endDate:"-1d",
            });
            $('input[name="tanggaltl"]').datepicker({
                firstDay: 1,
                format: "yyyy-mm-dd",
                startDate:"-1w",
                endDate:"-1d",
            });
            $('input[name="tanggalrp"]').datepicker({
                firstDay: 1,
                format: "yyyy-mm-dd",
                startDate:"-1w",
                endDate:"-1d",
            });
            $('input[name="tanggalit"]').datepicker({
                firstDay: 1,
                format: "yyyy-mm-dd",
                startDate:"-1w",
                endDate:"-1d",
            });
        });

        var oTable;
        $(function() {
            oTable = $('#tableaja').DataTable({
                processing: true,
                serverSide: true,
                ajax: '<?php echo e(route('datatransrekap')); ?>',
                columns: [
                    { data: 'nip', name: 'nip' },
                    { data: 'nama', name: 'nama' },
                    { data: 'periode', name: 'periode' },
                    { data: 'ijin', name: 'ijin' },
                    { data: 'cuti', name: 'cuti' },
                    { data: 'sakit', name: 'sakit' },
                    { data: 'tugas_luar', name: 'tugas_luar' },
                    { data: 'tugas_belajar', name: 'tugas_belajar' },
                    { data: 'rapatundangan', name: 'rapatundangan' },
                    { data: 'ijinterlambat', name: 'ijinterlambat' }
                ]
            });
        });
    </script>
    <script type="text/javascript">
        $(document).on('click','.modal_ijin',function () {
                $('#lamaijin').attr('disabled',false);
                $('#tanggalijin').attr('disabled',false);
                $('#fileijin').attr('disabled',false);
                $('#simpanijin').attr('disabled',false);
                $('#simpanijin').html('Save');
                $('#nipijin').val($(this).data('nip'));
                $('#namaijin').val($(this).data('nama'));
                $('#tanggalijin').val('');
                $('#fileijin').val('');
                $('#sisalamaijin').val($(this).data('ijin'));
                $('#idijin').val($(this).data('id'));
                var select=parseInt($(this).data('ijin'));
                if(select=="0" && select==""){
                    $('#tanggalijin').attr('disabled','true');
                    $('#fileijin').attr('disabled','true');
                    $('#lamaijin').attr('disabled','true');
                    $('#simpanijin').attr('disabled','true');
                }
                else {
                    var select=select+1;
                    for (i = 1; i < select; i++) {
                        $('#lamaijin').append('<option value="'+i+'">'+i+'</option>');
                    }
                    $('#tanggalijin').removeAttr('disabled');
                    $('#fileijin').removeAttr('disabled');
                    $('#lamaijin').removeAttr('disabled');
                    $('#simpanijin').removeAttr('disabled');
                }
        });

        $(document).on('click','.modal_sakit',function () {
            $('#lamasakit').attr('disabled',false);
            $('#tanggalsakit').attr('disabled',false);
            $('#filesakit').attr('disabled',false);
            $('#simpansakit').attr('disabled',false);
            $('#simpansakit').html('Save');
            $('#nipsakit').val($(this).data('nip'));
            $('#namasakit').val($(this).data('nama'));
            $('#tanggalsakit').val('');
            $('#sisalamasakit').val($(this).data('sakit'));
            $('#filesakit').val('');
            $('#idsakit').val($(this).data('id'));
            var select=parseInt($(this).data('sakit'));
            if(select=="0" && select==""){
                $('#tanggalsakit').attr('disabled','true');
                $('#filesakit').attr('disabled','true');
                $('#lamasakit').attr('disabled','true');
                $('#simpansakit').attr('disabled','true');
            }
            else {
                var select=select+1;
                for (i = 1; i < select; i++) {
                    $('#lamasakit').append('<option value="'+i+'">'+i+'</option>');
                }
                $('#tanggalsakit').removeAttr('disabled');
                $('#filesakit').removeAttr('disabled');
                $('#lamasakit').removeAttr('disabled');
                $('#simpansakit').removeAttr('disabled');
            }
        });

        $(document).on('click','.modal_cuti',function () {
            $('#lamacuti').attr('disabled',false);
            $('#tanggalcuti').attr('disabled',false);
            $('#filecuti').attr('disabled',false);
            $('#simpancuti').attr('disabled',false);
            $('#simpancuti').html('Save');
            $('#nipcuti').val($(this).data('nip'));
            $('#namacuti').val($(this).data('nama'));
            $('#tanggalcuti').val('');
            $('#filecuti').val('');
            $('#sisalamacuti').val($(this).data('cuti'));
            $('#idcuti').val($(this).data('id'));
            var select=parseInt($(this).data('cuti'));
            if(select=="0" && select==""){
                $('#tanggalcuti').attr('disabled','true');
                $('#filecuti').attr('disabled','true');
                $('#lamacuti').attr('disabled','true');
                $('#simpancuti').attr('disabled','true');
            }
            else {
                var select=select+1;
                for (i = 1; i < select; i++) {
                    $('#lamacuti').append('<option value="'+i+'">'+i+'</option>');
                }
                $('#tanggalcuti').removeAttr('disabled');
                $('#filecuti').removeAttr('disabled');
                $('#lamacuti').removeAttr('disabled');
                $('#simpancuti').removeAttr('disabled');
            }
        });

        $(document).on('click','.modal_tb',function () {
            $('#lamatb').attr('disabled',false);
            $('#tanggaltb').attr('disabled',false);
            $('#filetb').attr('disabled',false);
            $('#simpantb').attr('disabled',false);
            $('#simpantb').html('Save');
            $('#niptb').val($(this).data('nip'));
            $('#namatb').val($(this).data('nama'));
            $('#tanggaltb').val('');
            $('#sisalamatb').val($(this).data('tb'));
            $('#filetb').val('');
            $('#idtb').val($(this).data('id'));
            var select=parseInt($(this).data('tb'));
            if(select=="0" && select==""){
                $('#tanggaltb').attr('disabled','true');
                $('#filetp').attr('disabled','true');
                $('#lamatb').attr('disabled','true');
                $('#simpantb').attr('disabled','true');
            }
            else {
                var select=select+1;
                for (i = 1; i < select; i++) {
                    $('#lamatb').append('<option value="'+i+'">'+i+'</option>');
                }
                $('#tanggaltb').removeAttr('disabled');
                $('#filetb').removeAttr('disabled');
                $('#lamatb').removeAttr('disabled');
                $('#simpantb').removeAttr('disabled');
            }
        });

        $(document).on('click','.modal_tl',function () {
            $('#lamatl').attr('disabled',false);
            $('#tanggaltl').attr('disabled',false);
            $('#filetl').attr('disabled',false);
            $('#simpantl').attr('disabled',false);
            $('#simpantl').html('Save');
            $('#niptl').val($(this).data('nip'));
            $('#namatl').val($(this).data('nama'));
            $('#tanggaltl').val('');
            $('#sisalamatl').val($(this).data('tl'));
            $('#filetl').val('');
            $('#idtl').val($(this).data('id'));
            var select=parseInt($(this).data('tl'));
            if(select=="0" && select==""){
                $('#tanggaltl').attr('disabled','true');
                $('#filetl').attr('disabled','true');
                $('#lamatl').attr('disabled','true');
                $('#simpantl').attr('disabled','true');
            }
            else {
                var select=select+1;
                for (i = 1; i < select; i++) {
                    $('#lamatl').append('<option value="'+i+'">'+i+'</option>');
                }
                $('#tanggaltl').removeAttr('disabled');
                $('#filetl').removeAttr('disabled');
                $('#lamatl').removeAttr('disabled');
                $('#simpantl').removeAttr('disabled');
            }
        });

        $(document).on('click','.modal_rp',function () {
            $('#lamarp').attr('disabled',false);
            $('#tanggalrp').attr('disabled',false);
            $('#filerp').attr('disabled',false);
            $('#simpanrp').attr('disabled',false);
            $('#simpanrp').html('Save');
            $('#niprp').val($(this).data('nip'));
            $('#namarp').val($(this).data('nama'));
            $('#tanggalrp').val('');
            $('#filerp').val('');
            $('#sisalamarp').val($(this).data('rp'));
            $('#idrp').val($(this).data('id'));
            var select=parseInt($(this).data('rp'));
            if(select=="0" && select==""){
                $('#tanggalrp').attr('disabled','true');
                $('#filerp').attr('disabled','true');
                $('#lamarp').attr('disabled','true');
                $('#simpanrp').attr('disabled','true');
            }
            else {
                var select=select+1;
                for (i = 1; i < select; i++) {
                    $('#lamarp').append('<option value="'+i+'">'+i+'</option>');
                }
                $('#tanggalrp').removeAttr('disabled');
                $('#filerp').removeAttr('disabled');
                $('#lamarp').removeAttr('disabled');
                $('#simpanrp').removeAttr('disabled');
            }
        });

        $(document).on('click','.modal_it',function () {
            $('#lamait').attr('disabled',false);
            $('#tanggalit').attr('disabled',false);
            $('#fileit').attr('disabled',false);
            $('#simpanit').attr('disabled',false);
            $('#simpanit').html('Save');
            $('#nipit').val($(this).data('nip'));
            $('#namait').val($(this).data('nama'));
            $('#tanggalit').val('');
            $('#fileit').val('');
            $('#sisalamait').val($(this).data('it'));
            $('#idit').val($(this).data('id'));
            var select=parseInt($(this).data('it'));
            if(select=="0" && select==""){
                $('#tanggalit').attr('disabled','true');
                $('#fileit').attr('disabled','true');
                $('#lamait').attr('disabled','true');
                $('#simpanit').attr('disabled','true');
            }
            else {
                var select=select+1;
                for (i = 1; i < select; i++) {
                    $('#lamait').append('<option value="'+i+'">'+i+'</option>');
                }
                $('#tanggalit').removeAttr('disabled');
                $('#fileit').removeAttr('disabled');
                $('#lamait').removeAttr('disabled');
                $('#simpanit').removeAttr('disabled');
            }
        });

//        $(document).ajaxStart(function () {
//            Pace.restart()
//        })

        $(document).on('click','#simpanijin',function (){
            var sisaijin=$('#sisalamaijin').val()-$('#lamaijin').val();
            $('#sisalamaijin').val(sisaijin);

            $.ajax({
                type:'post',
                url:'<?php echo e(url('transrekap/postijin')); ?>',
                data: new FormData($('#formijin')[0]),
                dataType:'json',
                async:false,
                processData: false,
                contentType: false,
                beforeSend:function () {
                    $('#lamaijin').attr('disabled',true);
                    $('#tanggalijin').attr('disabled',true);
                    $('#fileijin').attr('disabled',true);
                    $('#simpanijin').attr('disabled',true);
                    $('#simpanijin').html('<i class="fa fa-spin fa-circle-o-notch"></i> Loading');
                },
                success:function(response){
                    $('#lamaijin').attr('disabled',false);
                    $('#tanggalijin').attr('disabled',false);
                    $('#fileijin').attr('disabled',false);
                    $('#simpanijin').attr('disabled',false);
                    $('#simpanijin').html('Save');

                    if((response.errors)){
                        swal("Simpan Gagal !", "", "error");
                        $('#modal_ijin').modal('hide');
                    }
                    else
                    {
                        swal("Simpan Sukses !", "", "success");
                        $('#modal_ijin').modal('hide');
                        oTable.ajax.reload();
                    }
                },
            });
        });

        $(document).on('click','#simpansakit',function (){
            var sisaijin=$('#sisalamasakit').val()-$('#lamasakit').val();
            $('#sisalamasakit').val(sisaijin);
            $.ajax({
                type:'post',
                url:'<?php echo e(url('transrekap/postsakit')); ?>',
                data: new FormData($('#formsakit')[0]),
                dataType:'json',
                async:false,
                processData: false,
                contentType: false,
                beforeSend:function () {
                    $('#lamasakit').attr('disabled',true);
                    $('#tanggalsakit').attr('disabled',true);
                    $('#filesakit').attr('disabled',true);
                    $('#simpansakit').attr('disabled',true);
                    $('#simpansakit').html('<i class="fa fa-spin fa-circle-o-notch"></i> Loading');
                },
                success:function(response){
                    if((response.errors)){
                        swal("Simpan Gagal !", "", "error");
                        $('#modal_sakit').modal('hide');
                    }
                    else
                    {
                        swal("Simpan Sukses !", "", "success");
                        $('#modal_sakit').modal('hide');
                        oTable.ajax.reload();
                    }
                },
            });
        });

        $(document).on('click','#simpancuti',function (){
            var sisaijin=$('#sisalamacuti').val()-$('#lamacuti').val();
            $('#sisalamacuti').val(sisaijin);
            $.ajax({
                type:'post',
                url:'<?php echo e(url('transrekap/postcuti')); ?>',
                data: new FormData($('#formcuti')[0]),
                dataType:'json',
                async:false,
                processData: false,
                contentType: false,
                beforeSend:function () {
                    $('#lamacuti').attr('disabled',true);
                    $('#tanggalcuti').attr('disabled',true);
                    $('#filecuti').attr('disabled',true);
                    $('#simpancuti').attr('disabled',true);
                    $('#simpancuti').html('<i class="fa fa-spin fa-circle-o-notch"></i> Loading');
                },
                success:function(response){
                    if((response.errors)){
                        swal("Simpan Gagal !", "", "error");
                        $('#modal_cuti').modal('hide');
                    }
                    else
                    {
                        swal("Simpan Sukses !", "", "success");
                        $('#modal_cuti').modal('hide');
                        oTable.ajax.reload();
                    }
                },
            });
        });

        $(document).on('click','#simpantb',function (){
            var sisaijin=$('#sisalamatb').val()-$('#lamatb').val();
            $('#sisalamatb').val(sisaijin);
            $.ajax({
                type:'post',
                url:'<?php echo e(url('transrekap/posttb')); ?>',
                data: new FormData($('#formtb')[0]),
                dataType:'json',
                async:false,
                processData: false,
                contentType: false,
                beforeSend:function () {
                    $('#lamatb').attr('disabled',true);
                    $('#tanggaltb').attr('disabled',true);
                    $('#filetb').attr('disabled',true);
                    $('#simpantb').attr('disabled',true);
                    $('#simpantb').html('<i class="fa fa-spin fa-circle-o-notch"></i> Loading');
                },
                success:function(response){
                    if((response.errors)){
                        swal("Simpan Gagal !", "", "error");
                        $('#modal_tb').modal('hide');
                    }
                    else
                    {
                        swal("Simpan Sukses !", "", "success");
                        $('#modal_tb').modal('hide');
                        oTable.ajax.reload();
                    }
                },
            });
        });

        $(document).on('click','#simpantl',function (){
            var sisaijin=$('#sisalamatl').val()-$('#lamatl').val();
            $('#sisalamatl').val(sisaijin);
            $.ajax({
                type:'post',
                url:'<?php echo e(url('transrekap/posttl')); ?>',
                data: new FormData($('#formtl')[0]),
                dataType:'json',
                async:false,
                processData: false,
                contentType: false,
                beforeSend:function () {
                    $('#lamatl').attr('disabled',true);
                    $('#tanggaltl').attr('disabled',true);
                    $('#filetl').attr('disabled',true);
                    $('#simpantl').attr('disabled',true);
                    $('#simpantl').html('<i class="fa fa-spin fa-circle-o-notch"></i> Loading');
                },
                success:function(response){
                    if((response.errors)){
                        swal("Simpan Gagal !", "", "error");
                        $('#modal_tl').modal('hide');
                    }
                    else
                    {
                        swal("Simpan Sukses !", "", "success");
                        $('#modal_tl').modal('hide');
                        oTable.ajax.reload();
                    }
                },
            });
        });

        $(document).on('click','#simpanrp',function (){
            var sisaijin=$('#sisalamarp').val()-$('#lamarp').val();
            $('#sisalamarp').val(sisaijin);
            $.ajax({
                type:'post',
                url:'<?php echo e(url('transrekap/postrp')); ?>',
                data: new FormData($('#formrp')[0]),
                dataType:'json',
                async:false,
                processData: false,
                contentType: false,
                beforeSend:function () {
                    $('#lamarp').attr('disabled',true);
                    $('#tanggalrp').attr('disabled',true);
                    $('#filerp').attr('disabled',true);
                    $('#simpanrp').attr('disabled',true);
                    $('#simpanrp').html('<i class="fa fa-spin fa-circle-o-notch"></i> Loading');
                },
                success:function(response){
                    if((response.errors)){
                        swal("Simpan Gagal !", "", "error");
                        $('#modal_rp').modal('hide');
                    }
                    else
                    {
                        swal("Simpan Sukses !", "", "success");
                        $('#modal_rp').modal('hide');
                        oTable.ajax.reload();
                    }
                },
            });
        });

        $(document).on('click','#simpanit',function (){
            var sisaijin=$('#sisalamait').val()-$('#lamait').val();
            $('#sisalamait').val(sisaijin);
            $.ajax({
                type:'post',
                url:'<?php echo e(url('transrekap/postit')); ?>',
                data: new FormData($('#formit')[0]),
                dataType:'json',
                async:false,
                processData: false,
                contentType: false,
                beforeSend:function () {
                    $('#lamait').attr('disabled',true);
                    $('#tanggalit').attr('disabled',true);
                    $('#fileit').attr('disabled',true);
                    $('#simpanit').attr('disabled',true);
                    $('#simpanit').html('<i class="fa fa-spin fa-circle-o-notch"></i> Loading');
                },
                success:function(response){
                    if((response.errors)){
                        swal("Simpan Gagal !", "", "error");
                        $('#modal_it').modal('hide');
                    }
                    else
                    {
                        swal("Simpan Sukses !", "", "success");
                        $('#modal_it').modal('hide');
                        oTable.ajax.reload();
                    }
                },
            });
        });
    </script>


    </body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>">
<!-- Ionicons -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>">
<!-- daterange picker -->
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/select2/dist/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
    <body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <b>REGISTER EABSEN</b>
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body">
            <p class="login-box-msg">Daftar dengan data yang sesuai dengan akun anda.</p>

            <form action="/registerpost" method="POST">
                <div class="form-group has-feedback <?php if($errors->has('email')): ?>
                        has-error
                     <?php endif; ?>">
                    <input type="email" id="email" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback <?php if($errors->has('username')): ?>
                       has-error
                    <?php endif; ?>">
                    <input type="text" id="username" name="username" class="form-control" value="<?php echo e(old('username')); ?>" placeholder="Username">
                    <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback <?php if($errors->has('password')): ?>
                        has-error
                     <?php endif; ?>">
                    <input type="password" id="password" name="password" class="form-control" placeholder="Password">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback <?php if($errors->has('name')): ?>
                        has-error
                     <?php endif; ?>">
                    <input type="text" id="name" name="name" class="form-control" placeholder="Nama" value="<?php echo e(old('name')); ?>">
                    <input type="hidden" id="selectrole" name="selectrole" value="1">
                    <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                </div>

                <?php echo e(csrf_field()); ?>

                <div class="form-group has-feedback">
                    <select class="form-control select2" id="selectinstansi" name="selectinstansi" style="width: 100%;">
                        <?php $__currentLoopData = $instansis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instansi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($instansi->id); ?>"><?php echo e($instansi->namaInstansi); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="row">
                    <!-- /.col -->
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Daftar</button>
                    </div>
                    <!-- /.col -->
                    <hr>
                    <?php if(count($errors)>0): ?>
                    <div class="col-xs-12">
                        <div class="alert alert-danger alert-dismissible">
                            <button class="close" type="button" data-dismiss="alert" aria-hidden="true">×</button>
                            <?php if($errors->has('email')): ?>
                               Kesalahan mengisi email !
                            <?php elseif($errors->has('username')): ?>
                                Kesalahan mengisi username !
                            <?php elseif($errors->has('password')): ?>
                                Kesalahan mengisi password !
                            <?php elseif($errors->has('name')): ?>
                                Kesalahan mengisi nama !
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <!-- /.login-box-body -->
    </div>
    <!-- /.login-box -->

    <script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e(asset('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <!-- InputMask -->
    <script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>
    <!-- date-range-picker -->
    <script src="<?php echo e(asset('bower_components/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <!-- bootstrap datepicker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <!-- bootstrap color picker -->
    <script src="<?php echo e(asset('bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>"></script>
    <!-- bootstrap time picker -->
    <script src="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
    <!-- SlimScroll -->
    <script src="<?php echo e(asset('bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
    <!-- iCheck 1.0.1 -->
    <script src="<?php echo e(asset('plugins/iCheck/icheck.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('bower_components/fastclick/lib/fastclick.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
    <script>
        $(function () {
            $('input').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-blue',
                increaseArea: '20%' // optional
            });
        });
    </script>
    <script>
        $(function () {
            //Initialize Select2 Elements
            $('#instansi').select2();
        })
    </script>
    </body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
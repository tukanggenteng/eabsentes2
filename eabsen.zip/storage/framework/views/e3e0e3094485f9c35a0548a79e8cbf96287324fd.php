<html>
<head>

</head>
<body>

<input type="text" id="instansi">

<input type="text" id="tahun">
<button id="cari">cari</button>
<canvas id="container"></canvas>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type="text/javascript">

    var apel = new Array();
    var absen = new Array();

    $("#cari").click(function () {
        apel=[];
        absen=[];
        $("#container").html("");

        var tahun = $("#tahun").val();
        var instansi = $("#instansi").val();

        var url = "<?php echo e(url('/chart/datacari')); ?>";

        $.get(url,{ tahun: tahun, instansi: instansi }, function(response) {

            absen.push(response['Absen']);
            apel.push(response['Apel']);

            var ctx = $('#container');
            var stackedLine = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ["JAN", "FEB", "MAR", "APR", "JUN", "JUL", "AGS", "SEPT", "OKT", "NOV", "DES"],
                    datasets: [
                        {
                            label: "Persentase Apel",
                            data: apel[0],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)'
                            ],
                            borderColor: [
                                'rgba(255,99,132,1)'
                            ],
                            borderWidth: 1
                        },
                        {
                            label: "Persentase Tidak Hadir",
                            data: absen[0],
                            backgroundColor: [
                                'rgba(54, 162, 235, 0.2)'
                            ],
                            borderColor: [
                                'rgba(54, 162, 235, 1)'
                            ],
                            borderWidth: 1
                        }
                    ]
                }
            });
        });
    });

$("document").ready(function(){
    var url = "<?php echo e(url('/chart/data')); ?>";

    $.get(url, function(response) {

        absen.push(response['Absen']);
        apel.push(response['Apel']);

        var ctx = $('#container');
        var stackedLine = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ["JAN", "FEB", "MAR", "APR", "JUN", "JUL", "AGS", "SEPT", "OKT", "NOV", "DES"],
                datasets: [
                    {
                        label: "Persentase Apel",
                        data: apel[0],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)'
                        ],
                        borderColor: [
                            'rgba(255,99,132,1)'
                        ],
                        borderWidth: 1
                    },
                    {
                        label: "Persentase Tidak Hadir",
                        data: absen[0],
                        backgroundColor: [
                            'rgba(54, 162, 235, 0.2)'
                        ],
                        borderColor: [
                            'rgba(54, 162, 235, 1)'
                        ],
                        borderWidth: 1
                    }
                ]
            }
        });
    });

});
</script>
</body>
</html>